//Cody Kohlbrecher and Bjorn Hermano 
//CS170 Lab0
//Due October 12th, 2026

#include <stddef.h>
#include <stdio.h>
#include "my_malloc.h"

struct malloc_stc
{
        struct malloc_stc *next;
        struct malloc_stc *prev;
        int size;
        unsigned char *buffer;
};


static unsigned char BigBuffer[MAX_MALLOC_SIZE];
static struct malloc_stc *free_list_head = NULL;

void InitMyMalloc() 
{
    struct malloc_stc *first = (struct malloc_stc *)BigBuffer;
    first->next = NULL;
    first->prev = NULL;
    first->size = MAX_MALLOC_SIZE - sizeof(struct malloc_stc);
    first->buffer = BigBuffer + sizeof(struct malloc_stc);
    free_list_head = first;


}

void *MyMalloc(int size)
{
    int leftover; 
    if(size <= 0 || size > MAX_MALLOC_SIZE ) //invalid memory sizing 
    {
        return NULL; 
    }
    int temp = 8;

    while(size > temp)//round size to a multiple of 8 bytes
    {
        temp += 8;
    }
    size = temp; 
    
    struct malloc_stc *ptr = free_list_head; 

    while(ptr != NULL && ptr->size < size)//find first block of adequite size
    {
        ptr = ptr->next;
    }

    if(ptr == NULL)//none exists
    {
        return NULL; //failure
    }

    leftover = ptr->size - size; 

    if (leftover >= sizeof(struct malloc_stc) + 8) // check that we have space for more free memory after this memory allocation call
    {
        struct malloc_stc *remaining = (struct malloc_stc *)(ptr->buffer + size);
        remaining->next = ptr->next;
        remaining->prev = ptr->prev; 
        remaining->size = leftover - sizeof(struct malloc_stc);
        remaining->buffer = (unsigned char *)remaining + sizeof(struct malloc_stc);
        if(ptr->prev != NULL)//reassign free prev
        {
            ptr->prev->next = remaining; 
        }
        else
        {
            free_list_head = remaining;//if the free allocated block is the head of the linked list
        }
        if(ptr->next != NULL)//reasign free next
        {
            ptr->next->prev = remaining; 
        }
        ptr->size = size; 
    }
    else //update neighbors 
    {
        if(ptr->prev != NULL)
        {
            ptr->prev->next = ptr->next; 
        }
        else
        {
            free_list_head = ptr->next;
        }

        if(ptr->next != NULL)
        {
            ptr->next->prev = ptr->prev;
        }

    }
    return ptr->buffer; 
}



void MyFree(void *buffer)
{
    //check valid address
    if(buffer == NULL)
    {
        return; 
    }
    struct malloc_stc *block = (struct malloc_stc *)((unsigned char *)buffer - sizeof(struct malloc_stc)); //adress of the header of buffer ^
    //insert the freed block into the free list
    struct malloc_stc *prev = NULL;
    struct malloc_stc *ptr = free_list_head;
    while(ptr != NULL && (unsigned char *)ptr < (unsigned char *)block) // find both neighbors
    {
        prev = ptr;
        ptr = ptr->next;
    }

    block->next = ptr;
    block->prev = prev;

    if(prev == NULL)//i fixed my way too complicated if statement xD
    {
        free_list_head = block;
    }
    else
    {
        prev->next = block;
    }
    if(ptr != NULL)
    {
        ptr->prev = block;
    }
    //merge the neighbors if they are next to each other in memory
#ifndef NO_COALESCE
    if(block->prev != NULL && block->prev->buffer + block->prev->size == (unsigned char *)block)
    {

        prev->size += sizeof(struct malloc_stc) + block->size;
        prev->next = block->next;

        if(block->next != NULL)
        {
            block->next->prev = prev;
        }

        block = prev;
    }

    if(block->next != NULL && block->buffer + block->size == (unsigned char *)block->next)
    {

        block->size += sizeof(struct malloc_stc) + ptr->size;
        block->next = ptr->next;

        if(block->next != NULL)
        {
            block->next->prev = block;
        }
        
    } 
#endif

}

void PrintMyMallocFreeList()
{
    struct malloc_stc *ptr = free_list_head;

    while(ptr != NULL)
    {
        printf("block: %p\n", 
        (void *)ptr);
        printf("\tsize: %d\n", 
        ptr->size);

        if(ptr->next == NULL)
            printf("\tnext: 0x0\n");
        else
            printf("\tnext: %p\n", 
            (void *)ptr->next);

        if(ptr->prev == NULL)
            printf("\tprev: 0x0\n");
        else
            printf("\tprev: %p\n", 
            (void *)ptr->prev);

        printf("\tbuffer: %p\n", 
        (void *)ptr->buffer);

        ptr = ptr->next;
    }
}
